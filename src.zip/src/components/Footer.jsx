import React, { Component } from "react";
export default class Footer extends Component{
    render(){
        return(
            <>
            <footer>
            <h4>TM & Copyright 2024 Burger King Company LLC. All Rights Reserved.| 
                <a href="">Do Not Sell Or Share My Personal Information</a></h4>
            </footer>
            </>
        )
    }
}