import React, { Component } from "react";
import Products from "./components/Products";
import Header from "./components/Header";
import "./style.css";
import Footer from "./components/Footer";
export default class App extends Component{
  constructor(props){
    super(props);
    this.state={prods:[]};
}
componentDidMount(){
    try{
        let api=fetch("https://fakestoreapi.com/products");
        api.then(x=>x.json()).then(x1=>this.setState({prods:x1}))
        
    }
    catch(err){
        console.log(err)
    }
}
  render(){
    // console.log(this.state.prods);
    return(
      <>
      <Header/>
      <div id="prodDiv">
        {this.state.prods.map(product=><Products
          prodIndex={product.id}
          prodImage={product.image}
          prodTitle={product.title}
          prodPrice={`$${product.price}`}
          prodDescription={product.description}
          prodCategory={product.category}
          prodRating={product.rating.rate}
          prodCount={product.rating.count}/>)}
      </div>
      <Footer/>
      </>
    )
  }
}
// export {count};